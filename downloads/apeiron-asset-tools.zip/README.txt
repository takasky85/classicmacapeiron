Apeiron asset tools
===================

Turns your own copy of Apeiron 1.0.3 into the folder of artwork, sounds and fonts that the SDL3
port needs. The port does not ship Ambrosia's assets; you make them from the game you have.

What you need
  * Apeiron_1.0.3.zip (the Mac game, as you downloaded it)
  * Python 3 and Pillow. On Windows, install Python from python.org (tick "Add to PATH"); the
    .bat file below installs Pillow for you.
  * Fonts are optional, and free stand-ins are in this zip: pixChicago.ttf (Etienne Desclides)
    for Chicago and Geneva9.1.otf (Kelsey Higham, SIL Open Font License) for Geneva. See
    FONT-ATTRIBUTION.txt. The Apple fonts are not needed.
      - Geneva.zip / Chicago.zip (Apple's fonts, from a Mac): used instead when present.

How to use it
  Windows:  unzip this, then drag Apeiron_1.0.3.zip onto "Extract Apeiron Assets.bat".
            (Or put the game zip in Downloads, or in this folder, and double-click the .bat.)
  Anywhere: python3 extract_assets.py Apeiron_1.0.3.zip

The result is a folder called apeiron_classic_assets, written next to the game zip.
  Windows: put it beside apeiron.exe.
  Google TV / Android: put it in the Download folder.

For the exact original fonts, keep Geneva.zip and Chicago.zip in the same folder as the game zip
(or in Downloads) and run it again. It finds them by itself.

If something goes wrong, copy the whole message in the window and send it on.
