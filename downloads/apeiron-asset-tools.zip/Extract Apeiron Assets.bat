@echo off
rem Drag Apeiron_1.0.3.zip onto this file, or double-click it with the zip in Downloads.
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python 3 is not installed. Get it from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" in the installer, then try again.
  pause
  exit /b 1
)
%PY% -c "import PIL" >nul 2>nul || (
  echo Installing Pillow, the image library this needs...
  %PY% -m pip install --user pillow
)
%PY% extract_assets.py %*
